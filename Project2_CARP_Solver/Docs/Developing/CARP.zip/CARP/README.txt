This package contains:
    CARP.pdf                              # Introduction to CARP
    sample.dat                            # A sample describe the input and output
    CARP_format.txt                       # The format of the CARP instance file
    CARP_samples/                         # Some CARP instance files
